This branch will contain all the current symbols distributed with KiCad, but categorized by the manufacturer name and a functional groups/features. Wherever possible new symbols were also added, which the original libraries does not contain.

All symbols will be redrawn using My own (unwritten) drawing policy. Thus symbols in these libraries might not (in most cases: they won't) be suitable to the existing schematics, based on these components from legacy libraries.

If you want to use following libraries you **have to know** that this repository is currently under development and **everything may change**. Also please **do not** merge this branch into other branches or KiCad releases until it will be fully finished. The completion date is not specified.

Kerusey Karyu
